from interface import btn_arret_clicked
from modele import Mesure
from tkinter import *


def btn_arret_clicked():

    pass

def btn_debuter_clicked():
    
    pass

def btn_mesure_clicked():
    pass

class Interface :
    def __init__(self, principal, liste):
        self.principal = principal
        self.listeMesures = liste
        
        #création de la fenêtre
        principal = Tk()

        #titre de la fenetre principale
        principal.title("stockage de données")


        #ajout d'un cadre
        self.frm_principal = Frame(principal)
        self.frm_principal.pack()

        #boutton qu'on utilisera pour arreter le systeme
        self.btn_arretSysteme = Button(self.frm_principal, text="Arrêt du système", width=24)
        self.btn_arretSysteme ["command"] = self.btn_arret_clicked
        self.btn_arretSysteme.grid(column=2, row=1,columnspan=2)

        #boutton qui sera utilisé pour demarrer le systeme
        self.btn_demarrerSysteme = Button(self.frm_principal, text="Démarrage du système", width=24)
        self.btn_demarrerSysteme ["command"] = self.btn_debuter_clicked
        self.btn_demarrerSysteme.grid(column=0, row=1, columnspan=2)

        self.txt_info = Text(self.frm_principal , width=60,height=15 )
        self.txt_info.grid(column=0,row=2, columnspan=4)

        #entré ou la description sera écrite.
        self.ety_description = Entry(self.frm_principal, width=40, text="Description", state=DISABLED)
        self.ety_description.grid(column=0, row=3,columnspan=3)

        #boutton pour pouvoir prendre la mesur
        self.btn_prendreMesure = Button(self.frm_principal, text="prendre mesure", state=DISABLED)
        self.btn_prendreMesure ["command"] = self.btn_mesure_clicked
        self.btn_prendreMesure.grid(column=3, row=3,columnspan=2)

        #label qui nous indique si la captation est en marche ou arrété.
        self.lbl_captation = Label(self.frm_principal, text="CAPTATION ARRÊTÉE", bg='red', width=55)
        self.lbl_captation.grid(column=1, row=4,columnspan=3)


        principal.mainloop()
        