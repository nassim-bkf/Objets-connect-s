from modele import Mesure


def affichageListeMesure():
    listeMesures = Mesure.getListeMesure()
    return vue.affichageListeMesureVue(listeMesures)