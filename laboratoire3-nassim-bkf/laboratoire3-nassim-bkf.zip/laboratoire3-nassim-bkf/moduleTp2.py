class mesure:


    def __init__(self, noMesure, DateHeure, description):
        self.noMesure = noMesure
        self.DateHeure = DateHeure.datetime.now()
        self.description = description
       
    
    def __repr__(self):
        return self.description

    def afficherMesure(self):
        print("\nnumero mesure" + self.noMesure + "\ndate" + self.DateHeure + "\ndescription" + self.description )
    
