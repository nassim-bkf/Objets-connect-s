
import sqlite3

from gpiozero import exc


connexion = ""
nomBD = "distanceBD.db"
mesure = "mesure"
cle_no = "NoMesure"
cle_date = "dateHeure"
cle_distance = "Distance"
cle_description = "Description"





def connexionBD():
   
    try :
        
        connexion = sqlite3.connect("distanceBD.db")
        print("Ouverture de la base de données")
    except sqlite3.Error as error: 
        print("Erreur de connexion à la base de données", error)
        

def fermetureBD():
  
    if connexion:
        
        connexion.close()
        print("Fermeture de la base de données")
    else:
        print("Erreur de connexion à la base de données")


def verifierExisteTable(table):
    
    existe = False
    
    cur = connexion.cursor()
    
    sql_tableExiste =   "SELECT count(name)" \
                        "FROM sqlite_master" \
                        "WHERE type= 'table' AND name= ' " + table + "'"
                        
    try:
        
        cur.execute(sql_tableExiste)
        
        if cur.fetchone()[0] ==1:
            existe = True
        else:
            existe = False
    except sqlite3.Error as error:
        print("Erreur lors d'une opération sur la base de données", error)
        
    return existe


def creationTable():
    tableDistance = "CREATE TABLE" + mesure + " ( "\
        + cle_no + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"\
        + cle_date + " TEXT NOT NULL, "\
        + cle_distance + " FLOAT NOT NULL," \
        + cle_description + " TEXT NOT NULL);"    
    
    connexionBD()
    
    if verifierExisteTable(mesure):
        print("La table existe déjà")
    else:
        try:
            connexion.execute(mesure)
            print("Création de la table")
        except sqlite3.Error as error:
            print("Erreur lors d'une opération sur la base de données", error)

    fermetureBD()

def ajouterMesure(dateMesure, distanceMesure, descriptionMesure):
    sql_insert = "INSERT INTO" + mesure + " (" + cle_date + ", " + cle_distance + ", " + cle_description + ") VALUES (?, ?, ?);"
    
    connexionBD()
    
    try:
            
        cur_insert = connexion.cursor()
        donnees_param = (cle_date, cle_distance, cle_description)
        cur_insert.execute(sql_insert, donnees_param)
        #sauvegarde des données
        connexion.commit()
        print("Enregistrement ajouté dans la table")
        cur_insert.close()
    except sqlite3.Error as error:
        print("Erreur lors d'une opération sur la base de données", error)
    finally:        
        fermetureBD

def selectionListeMesure():
    
    sql_select = "SELECT" + cle_no + ", " + cle_date + ", " + cle_distance + ", " + cle_description + \
                 " FROM "+ mesure
                 
    connexionBD
    
    try:
        cur_select = connexion.cursor()
        cur_select.execute(sql_select)
        data = cur_select.fetchall()
    
    except sqlite3.Error as error:
        print("Erreur lors d'une opération sur la base de données", error)
    finally:
        fermetureBD()
    
    return data
        
    