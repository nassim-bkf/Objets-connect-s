
from tkinter import *
import datetime
from gpiozero import LED
from gpiozero import DistanceSensor
from time import sleep
import LCD1602
from threading import Thread
import moduleTp2
import gestionnaireBD as bd

DateHeure = datetime.datetime.now()
distance = 0
ledVert = LED(22)
ledRouge = LED(27)

methode = True
LCD1602.init(0x27, 1)



#methode qui permet d'analyser les distance avec le capteur et qui retourne la distance la plus proche
def capteurDistance():
    global methode
    global distance
    ultrason = DistanceSensor(echo=24,trigger=23,max_distance=1, threshold_distance=0.2)
#ecrit la mesure prise dans le LCD...    
    while methode :
        distance = "{:.5f}".format(ultrason.distance)
        
        LCD1602.clear()
        LCD1602.write(0,0, "il y'a une prise de mesure en cours")
        LCD1602.write(0,1,(distance))   
        
#Ecrit en paramettre la distance de l'objet le plus proche.        
        print("L'objet le plus proche est à une distance de " + "{:.5f}".format(ultrason.distance) + " m")
        sleep(5)
        print("")
        
#methode qui tend à allumer les LED en vert lorsque le bouton 'débuter' 
#démarre et débloque les entré de description et la prise de mesures
def btn_debuter_clicked():
    global methode
    methode = True
    ety_description.config(state=NORMAL)
    btn_prendreMesure.config(state=NORMAL)
    lbl_captation.config(text="CAPTATION DÉMARRÉE", bg='green')
    ledRouge.off()
    ledVert.on()
    Thread(target=capteurDistance).start()
    
#methode qui tend a arreter le systeme , le capteur arrete de fonctionner et 
#les entré de description et de prise de mesure sont bloqués.  Allume Le LED rouge     
def btn_arret_clicked():
    global methode
    methode = False
    ety_description.config(state=DISABLED)
    btn_prendreMesure.config(state=DISABLED)
    lbl_captation.config(text="CAPTATION ARRÊTÉE", bg='red')
    ledVert.off()
    ledRouge.on()
    
#lorsque on tente de rentrer une mesure sans description ,
#on nous dit quil faut mettre une description , si non , la mesure est valable.  
def btn_mesure_clicked():
    
    


    if (ety_description.get() == ''):
        print("il manque une description à notre mesure.")
        
        
    else:
        
        dateMesure = datetime.datetime.now()
        distanceMesure = distance
        descriptionMesure = ety_description.get
        
        bd.creationTable()
        bd.ajouterMesure(dateMesure + distanceMesure + descriptionMesure )
            
        
        txt_info.insert(END, DateHeure.strftime("%c") + " " + descriptionMesure + "\n")
            
        
        






#création de la fenêtre
principal = Tk()

#titre de la fenetre principale
principal.title("Système de captation")


#ajout d'un cadre
frm_principal = Frame(principal)
frm_principal.pack()

#boutton qu'on utilisera pour arreter le systeme
btn_arretSysteme = Button(frm_principal, text="Arrêt du système", width=24, command=btn_arret_clicked)
btn_arretSysteme.grid(column=2, row=1,columnspan=2)

#boutton qui sera utilisé pour demarrer le systeme
btn_demarrerSysteme = Button(frm_principal, text="Démarrage du système", width=24, command=btn_debuter_clicked)
btn_demarrerSysteme.grid(column=0, row=1, columnspan=2)

txt_info = Text(frm_principal , width=60,height=15 )
txt_info.grid(column=0,row=2, columnspan=4)

#entré ou la description sera écrite.
ety_description = Entry(frm_principal, width=40, text="Description", state=DISABLED)
ety_description.grid(column=0, row=3,columnspan=3)

#boutton pour pouvoir prendre la mesur
btn_prendreMesure = Button(frm_principal, text="prendre mesure", command=btn_mesure_clicked, state=DISABLED)
btn_prendreMesure.grid(column=3, row=3,columnspan=2)

#label qui nous indique si la captation est en marche ou arrété.
lbl_captation = Label(frm_principal, text="CAPTATION ARRÊTÉE", bg='red', width=55)
lbl_captation.grid(column=1, row=4,columnspan=3)


principal.mainloop()
