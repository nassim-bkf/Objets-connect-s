import json

class Mesure(object):
    def __init__ (self, noMesure, dateMesure, mesureDistance):
        self.noMesure = noMesure
        self.dateMesure = dateMesure
        self.mesureDistance = mesureDistance
    
    def mesureComplete(self):
        return ("%s > %s %s" % (self.dateMesure, self.mesureDistance))
    
    @classmethod
    
    def getListeMesure(self):
        with open("db.json", "r", encoding='utf-8') as fic:
            data_mesure = json.load(fic)
            resultat = []
            liste_mesure = data_mesure["resultat"]
            
            for i in range(len(liste_mesure)):
                mesure_dict = liste_mesure[i]
                mesure = Mesure(mesure_dict["noMesure"],mesure_dict["dateMesure"], mesure_dict["mesureDistance"])
                resultat.append(mesure)
                
            return resultat
                                