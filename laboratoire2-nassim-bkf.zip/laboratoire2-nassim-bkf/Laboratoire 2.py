import json
import moduleLabo2 as object
import sys
import codecs

#Ecriture des regles du jeux.
print ("labo 2 - Quiz 4B5 - Nassim Boukhnifer")
print ("choisissez la bonne réponse pour chaque question (a/b/c)")
print ("q pour quitter")

with open("questions.json", encoding="utf-8") as f:
    donnee = json.load(f)
    

#ecrire le nom à la console
nomParticipant = input("Entrez votre nom:")

pointage = 1
userInput = []
points = 0
stats = []


for i in donnee:
    print(str(pointage) + ") " + i["q"]
        + "\n[a] " + i["a"]
        + "\n[b] " + i["b"]
        + "\n[c] " + i["c"])
    print ("\n")
    

        
    pointage = pointage + 1
    #permet d'afficher un message si la réponse est celle qui est demandé ou pas , 
    #ainsi que le choix de quitter
    listeReponses = (input("Entrez l'option (a/b/c) ou q pour quitter:")).lower()
    userInput.append(i[str(listeReponses)])
    
    if listeReponses == i["rep"]:
        print("Bonne réponse!" + "\n")
        
        points = points + 1
    elif listeReponses == "q":
        print("Vous avez quitté la partie.")
        quit()
        break
        
    else :
        print("Mauvaise réponse. La bonne reponses est " + i["rep"]+ "\n")
        
   
        

# permet d'ecrire des information dans le fichier json outpout.json
afficherParticipant = {}
with open("output.json", "r", encoding="utf-8") as f:
        
    information = json.load(f)
afficherParticipant["name"] = nomParticipant
afficherParticipant["reponse"] = userInput
afficherParticipant["pointage"] = points
information.append(afficherParticipant)
with open("output.json", "w", encoding="utf-8") as f:
    json.dump(information, f,ensure_ascii=False, indent=4, sort_keys=True)