class Participante:
    def __init__(self, nomParticipant, listeReponses, pointages):
        self.nomParticipant = nomParticipant
        self.listeReponses = listeReponses
        self.pointages = pointages
        
    def __repr__(self):
        return self.nomParticipant
    
    def afficherParticipant(self):
        print("\nnom: " + self.nomParticipant + "\nliste de réponse" + self.listeReponses + "\npointages" + self.pointages)
     


     