from tkinter import *
import json 
import moduleLabo2 as participant


list_data = []

def onSelect(evt):
    txt_affichage.delete(1.0, END)
    w = evt.widget
    index = int(w.curselection()[0])
    valeur = lst_nom.get(lst_nom.curselection())
    txt_affichage.insert(INSERT,list_data[index].listeReponses)
    lbl_point.config(text="pointage: " + list_data[index].pointages)
    #print("nom: " + str(index) + " valeur: " + valeur)

 # fonction qui permettra d'afficher les nom du fichier output.json  
def btn_afficher_clicked():

    with open("output.json", encoding="utf-8") as f:
        donnee = json.load(f)
    
    index = 0

    for i in donnee:
        print(i["name"])
        list_data.append(participant.Participante(i["name"], str(i["reponse"]),str(i["pointage"])))
        lst_nom.insert(index,i["name"])
        print(str(i["reponse"]))
        
        index = index + 1 

#creation de ma fenêtre
principal = Tk()
principal.geometry("350x350")
principal.title("Labo2 - Quiz 4B5")

#creation du titre
lbl_nom = Label(principal, text=("Résultat Quiz 4B5 - Nassim Boukhnifer"))
lbl_nom.pack()

lbl_point = Label(principal, text=("pointage:"))
lbl_point.pack()


frm_principal = Frame(principal)
frm_principal.pack(side=LEFT)



lst_nom = Listbox(frm_principal)
lst_nom.bind("<<ListboxSelect>>", onSelect)
lst_nom.pack()




#ajout d'un bouton qui importera les résultat.
btn_afficher = Button(frm_principal,
                      text="importer résultats",
                      command=btn_afficher_clicked)
btn_afficher.pack(side =BOTTOM)

#ajout d'un champ texte (affichage) , ou sera affiché les réponses des participants.
txt_affichage = Text(frm_principal)
txt_affichage.pack(side=RIGHT)



principal.mainloop()