autreMessage = str(input("Autre message (O/N)?"))
while autreMessage == "O" : 

        choix = str(input("Crypter ou décrypter le message(choix C ou D)"))
 
        
        if choix == "C": 
                decalage =int (input("entrez le code de decalage(entre 0 et 25)"))
                message = str(input("entrez un message à crypter :"))

                # le tableau ASCII est utilisé ci dessou , la lettre A représente la 65iem decimal du tableau ASCII alors que le 'a' le 97iem.
                
                def encryptage (message, decalage) : 
                        resultat = ""
                
                        for i in range(len(message)):
                                char = message[i]
                                if (char.isupper()):
                                        resultat += chr((ord(char) + decalage - 65) % 26 + 65)
                                else: 
                                        resultat += chr((ord(char) + decalage - 97) % 26 + 97)    
                        return resultat

                

                print("Message crypté:" + encryptage(message, decalage))
                
                
        # Décryptage , formule contraire à l'encryptage. au lieux d'additionner on soustrait. 
        if choix =="D": 

                decalage_ =int (input("entrez le code de décalage(entre 0 et 25)"))
                message_ = str(input("entrez un message à Décrypter :"))
                
                def decryptage (message_, decalage_) : 
                        resultat_ = ""
                        
                        for i in range(len(message_)):
                                char = message_[i]
                                if (char.isupper()):
                                        resultat_ += chr((ord(char) - decalage_ - 65) % 26 + 65)
                                else: 
                                        resultat_ += chr((ord(char) - decalage_ - 97) % 26 + 97)    
                        return resultat_
                
                print("Message decrypté:" + decryptage(message_, decalage_))
                
        autreMessage = str(input("Autre message (O/N)?"))
        
      